import { computed, defineComponent } from 'vue'
import { exhaustivenessCheck } from 'misc/utils'

type Props = {
  id: 'play' | 'pause'
}

export const MessagerController = defineComponent<Props>((props, { slots }) => {
  const path = computed(() => {
    switch (props.id) {
      case 'play': {
        return (
          <path d="M30.28 23.23a16 16 0 1 0-7.05 7.05 5 5 0 0 1 7.05-7.05Zm-8.13-8.1a1 1 0 0 1 0 1.74l-8.64 5A1 1 0 0 1 12 21V11a1 1 0 0 1 1.5-.87l8.65 5Z" fill="currentColor"></path>
        )
      }
      case 'pause': {
        return (
          <path d="M30.28 23.23a16 16 0 1 0-7.05 7.05 5 5 0 0 1 7.05-7.05ZM11 11.6c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44c.21-.11.49-.11 1.05-.11h.8c.56 0 .84 0 1.05.1a1 1 0 0 1 .44.45c.11.21.11.49.11 1.05v8.8c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11h-.8c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45c-.11-.21-.11-.49-.11-1.05v-8.8Zm6 0c0-.56 0-.84.1-1.05a1 1 0 0 1 .45-.44c.21-.11.49-.11 1.05-.11h.8c.56 0 .84 0 1.05.1a1 1 0 0 1 .44.45c.11.21.11.49.11 1.05v8.8c0 .56 0 .84-.1 1.05a1 1 0 0 1-.45.44c-.21.11-.49.11-1.05.11h-.8c-.56 0-.84 0-1.05-.1a1 1 0 0 1-.44-.45c-.11-.21-.11-.49-.11-1.05v-8.8Z" fill="currentColor"></path>
        )
      }
      default: {
        return exhaustivenessCheck(props.id)
      }
    }
  })

  return (() => (
    <svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 32 32">
      {path.value}
      {slots.default?.()}
    </svg>
  ))
}, {
  props: ['id']
})
